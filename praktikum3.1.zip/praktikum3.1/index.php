<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <h2>Study Activity Score -STNF</h2>
        <a href="home.php">Home</a> | <a href="">Activity</a> | <a href="">My Score</a>
        | <a href="praktikum3/fungsi/index.php">Login</a>

        <hr>

    </header>    

    <footer>
        
        <p>Created By
            <a href="">MUHAMMAD Azfa Haqqani &copy;2017</a>
        </p>
    </footer>

</body>
</html>